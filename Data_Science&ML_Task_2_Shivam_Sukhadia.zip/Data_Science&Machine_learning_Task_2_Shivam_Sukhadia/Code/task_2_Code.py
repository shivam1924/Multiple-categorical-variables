import pandas as pd

# Sample data: Cities, Gender, Product Purchased, and Amount Spent
data = {
    'City': ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 
             'Gandhinagar'],
    'Gender': ['Male', 'Female', 'Male', 'Female', 'Male', 
               ],
    'Product_Purchased': ['Laptop', 'Phone', 'Tablet', 'Laptop', 'Phone',
                          ],
    'Amount': [50000, 25000, 15000, 55000, 23000, 
               ]
}
df = pd.DataFrame(data)
contingency_table = pd.crosstab(
    [df['City'], df['Gender']],    # Rows: City and Gender
    df['Product_Purchased'],      # Columns: Product Purchased
    values=df['Amount'],          # Values: Amount spent
    aggfunc='sum',                # Aggregation function: sum the amounts
    margins=True,                 # Add row/column totals
    margins_name="Total"          # Customize the name for totals
)

print("Contingency Table:\n", contingency_table)



